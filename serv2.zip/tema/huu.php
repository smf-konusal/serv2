<?php


require_once __DIR__."/bese.php";
require_once __DIR__."/tema.php";

\HUU\Bese::yukle();

require_once __DIR__."/function.php";
?>
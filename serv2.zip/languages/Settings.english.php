<?php
// Version: 2.1 RC3; Settings

global $settings;

// argument(s): images_url as saved in settings
$txt['theme_thumbnail_href'] = '%1$s/thumbnail.png';
$txt['theme_description'] = '<strong>Serv2 Theme By <a href="https://smf.konusal.com/" target="_blank">Cee</a></strong>';

?>

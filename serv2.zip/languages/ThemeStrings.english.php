<?php

$txt['themecopyright'] = ' <strong>Serv2 Theme By <a href="https://smf.konusal.com/" target="_blank">Cee</a></strong>';


$txt['bese_color_default'] = 'bese_color_default';
$txt['bese_color_primary'] = 'bese_color_primary';
$txt['bese_color_secondary'] = 'bese_color_secondary';
$txt['bese_default_mode'] = 'bese_default_mode';

$txt['bese_color_defaulte'] = 'Default is: %color%';


$txt['bese_default_mode'] = 'Default Mode';
$txt['bese_dark_mode'] = 'Dark Mode';
$txt['bese_light_mode'] = 'Light Mode';
$txt['bese_theme_settings'] = 'Serv2 Theme Settings';

$txt['bese_allow_user_modes'] = 'bese_allow_user_modes';
$txt['bese_allow_color_select'] = 'bese_allow_color_select';

$txt['default_bese_color'] = '#cfa782';
$txt['default_bese_primary'] = '#4b6465';
$txt['default_bese_secondary'] = '#393027';

?>